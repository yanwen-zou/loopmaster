# -*- coding: utf-8 -*-
"""
叫卖侠 · 双臂销售机器人 自助售卖下单后端
Flask + SQLite，零额外依赖之外只需 flask。

功能：
- 扫码打开网页计数 / 下单次数 / 销售总金额
- 机械臂执行次数、成功次数、失败次数
- 每次下单时间点、明细
- 用户输入 ID 登录，记录 IP，新用户赠送 200 月亮币（1 月亮币 = 1 元）
- 商品库存、支持后台新增商品 / 补货
"""
import os
import re
import ast
import glob
import json
import random
import sqlite3
from pathlib import Path
from datetime import datetime
from flask import Flask, request, jsonify, render_template, g, send_file

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "vending.db")
BACKUP_DIR = os.path.join(BASE_DIR, "backup")

# LoopViz 数据源（只读扫描 loopmaster 产物，不修改其代码）
LOOP_REPO = Path(BASE_DIR).parent / "loopmaster"
LOOP_SKILL_ROOT = LOOP_REPO / "loopmaster_agentic" / "skills" / "base"

# 机械臂模拟参数
ARM_SIMULATE = True          # True=下单自动模拟机械臂；False=等待真实机器人上报结果
ARM_SUCCESS_RATE = 0.90      # 单次抓取成功率
ARM_MAX_RETRY = 2            # 单个货品最多尝试次数
NEW_USER_COINS = 200.0       # 新用户赠送月亮币

# 开放给 agent 框架的写接口令牌：设了环境变量 LOOPMASTER_API_TOKEN 就要求校验，
# 不设则接口全开（本机开发用）。上阿里云建议务必设置。
API_TOKEN = os.environ.get("LOOPMASTER_API_TOKEN", "").strip()

app = Flask(__name__)


def check_token():
    """写接口令牌校验：未配置 API_TOKEN 时放行。"""
    if not API_TOKEN:
        return True
    tok = request.headers.get("X-API-Token", "") or request.args.get("token", "")
    return tok == API_TOKEN


# ----------------------------- 数据库 -----------------------------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def init_db():
    db = sqlite3.connect(DB_PATH)
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT NOT NULL DEFAULT '零食',
            price REAL NOT NULL,
            stock INTEGER NOT NULL DEFAULT 0,
            emoji TEXT DEFAULT '📦',
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            ip TEXT,
            coins REAL NOT NULL DEFAULT 0,
            visits INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            last_seen TEXT
        );

        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            ip TEXT,
            items TEXT NOT NULL,          -- JSON: [{id,name,price,qty,delivered}]
            total REAL NOT NULL,          -- 实际成功交付金额
            arm_exec INTEGER DEFAULT 0,
            arm_success INTEGER DEFAULT 0,
            arm_fail INTEGER DEFAULT 0,
            status TEXT NOT NULL,         -- success / partial / failed
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS stats (
            key TEXT PRIMARY KEY,
            value REAL NOT NULL DEFAULT 0
        );
        """
    )
    # 初始化统计计数器
    for k in ("page_visits", "arm_exec", "arm_success", "arm_fail"):
        db.execute("INSERT OR IGNORE INTO stats(key, value) VALUES(?, 0)", (k,))

    # 初始商品（上海人民币售价，单位元 = 月亮币）
    count = db.execute("SELECT COUNT(*) AS c FROM products").fetchone()[0]
    if count == 0:
        seed = [
            ("可口可乐 330ml", "饮料", 3.0, 20, "🥤"),
            ("百事可乐 330ml", "饮料", 3.0, 20, "🥤"),
            ("纯牛奶 250ml", "饮料", 5.0, 15, "🥛"),
            ("鲜橙汁 300ml", "饮料", 6.0, 12, "🧃"),
            ("现磨美式咖啡", "饮料", 12.0, 10, "☕"),
            ("农夫山泉 550ml", "饮料", 2.0, 30, "💧"),
            ("红牛能量饮料", "饮料", 6.0, 12, "🪫"),
            ("奥利奥饼干", "零食", 6.0, 18, "🍪"),
            ("原味吐司面包", "零食", 7.0, 14, "🍞"),
            ("乐事薯片", "零食", 8.0, 16, "🥔"),
            ("德芙巧克力", "零食", 10.0, 12, "🍫"),
            ("士力架", "零食", 5.0, 20, "🍬"),
        ]
        ts = now_str()
        db.executemany(
            "INSERT INTO products(name,category,price,stock,emoji,created_at) VALUES(?,?,?,?,?,?)",
            [(n, c, p, s, e, ts) for (n, c, p, s, e) in seed],
        )
    db.commit()
    db.close()


def snapshot_db(keep=30):
    """用 SQLite 在线 backup API 生成一致性快照，保留最近 keep 份。"""
    if not os.path.exists(DB_PATH):
        return None
    os.makedirs(BACKUP_DIR, exist_ok=True)
    ts = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    dst = os.path.join(BACKUP_DIR, f"vending_{ts}.db")
    src = sqlite3.connect(DB_PATH)
    bak = sqlite3.connect(dst)
    try:
        with bak:
            src.backup(bak)
    finally:
        bak.close()
        src.close()
    files = sorted(glob.glob(os.path.join(BACKUP_DIR, "vending_*.db")))
    while len(files) > keep:
        try:
            os.remove(files.pop(0))
        except OSError:
            break
    return dst


def bump_stat(db, key, delta=1):
    db.execute("UPDATE stats SET value = value + ? WHERE key = ?", (delta, key))


def stat_val(db, key):
    row = db.execute("SELECT value FROM stats WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else 0


# ----------------------------- 页面路由 -----------------------------
@app.route("/")
def index():
    # 扫码打开主页 = 一次访问
    db = get_db()
    bump_stat(db, "page_visits", 1)
    db.commit()
    return render_template("index.html")


@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")


@app.route("/admin")
def admin():
    return render_template("admin.html")


# ----------------------------- API -----------------------------
@app.route("/api/login", methods=["POST"])
def api_login():
    data = request.get_json(force=True, silent=True) or {}
    uid = (data.get("user_id") or "").strip()
    if not uid:
        return jsonify(ok=False, msg="请输入用户 ID"), 400
    ip = request.headers.get("X-Forwarded-For", request.remote_addr) or "unknown"
    ip = ip.split(",")[0].strip()

    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
    is_new = user is None
    if is_new:
        db.execute(
            "INSERT INTO users(id, ip, coins, visits, created_at, last_seen) VALUES(?,?,?,?,?,?)",
            (uid, ip, NEW_USER_COINS, 1, now_str(), now_str()),
        )
        coins = NEW_USER_COINS
    else:
        db.execute(
            "UPDATE users SET ip=?, visits=visits+1, last_seen=? WHERE id=?",
            (ip, now_str(), uid),
        )
        coins = user["coins"]
    db.commit()
    return jsonify(
        ok=True, user_id=uid, ip=ip, coins=coins, is_new=is_new,
        gift=NEW_USER_COINS if is_new else 0,
    )


@app.route("/api/products")
def api_products():
    db = get_db()
    rows = db.execute("SELECT * FROM products ORDER BY category DESC, id").fetchall()
    return jsonify(ok=True, products=[dict(r) for r in rows])


@app.route("/api/order", methods=["POST"])
def api_order():
    data = request.get_json(force=True, silent=True) or {}
    uid = (data.get("user_id") or "").strip()
    cart = data.get("items") or []
    if not uid:
        return jsonify(ok=False, msg="请先登录"), 400
    if not cart:
        return jsonify(ok=False, msg="购物篮为空"), 400

    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
    if not user:
        return jsonify(ok=False, msg="用户不存在，请重新登录"), 400

    # 校验库存 + 计算应付
    line_items = []
    need_total = 0.0
    for it in cart:
        pid = it.get("id")
        qty = int(it.get("qty") or 0)
        if qty <= 0:
            continue
        p = db.execute("SELECT * FROM products WHERE id = ?", (pid,)).fetchone()
        if not p:
            return jsonify(ok=False, msg=f"商品 {pid} 不存在"), 400
        if p["stock"] < qty:
            return jsonify(ok=False, msg=f"「{p['name']}」库存不足（剩 {p['stock']}）"), 400
        line_items.append({"id": p["id"], "name": p["name"], "price": p["price"],
                           "emoji": p["emoji"], "qty": qty})
        need_total += p["price"] * qty

    if not line_items:
        return jsonify(ok=False, msg="购物篮为空"), 400
    if user["coins"] < need_total:
        return jsonify(ok=False, msg=f"月亮币不足，需 {need_total:.0f}，余 {user['coins']:.0f}"), 400

    ip = request.headers.get("X-Forwarded-For", request.remote_addr) or "unknown"
    ip = ip.split(",")[0].strip()

    # 机械臂逐件抓取（模拟）
    arm_exec = arm_ok = arm_bad = 0
    delivered_total = 0.0
    for li in line_items:
        li["delivered"] = 0
        for _ in range(li["qty"]):
            success = False
            for _try in range(ARM_MAX_RETRY):
                arm_exec += 1
                if (not ARM_SIMULATE) or random.random() < ARM_SUCCESS_RATE:
                    success = True
                    arm_ok += 1
                    break
                else:
                    arm_bad += 1
            if success:
                li["delivered"] += 1
                delivered_total += li["price"]

    # 扣库存（按实际交付数量）+ 扣款
    for li in line_items:
        if li["delivered"] > 0:
            db.execute("UPDATE products SET stock = stock - ? WHERE id = ?",
                       (li["delivered"], li["id"]))
    db.execute("UPDATE users SET coins = coins - ? WHERE id = ?", (delivered_total, uid))

    all_delivered = all(li["delivered"] == li["qty"] for li in line_items)
    any_delivered = any(li["delivered"] > 0 for li in line_items)
    status = "success" if all_delivered else ("partial" if any_delivered else "failed")

    db.execute(
        """INSERT INTO orders(user_id, ip, items, total, arm_exec, arm_success,
           arm_fail, status, created_at) VALUES(?,?,?,?,?,?,?,?,?)""",
        (uid, ip, json.dumps(line_items, ensure_ascii=False), delivered_total,
         arm_exec, arm_ok, arm_bad, status, now_str()),
    )
    bump_stat(db, "arm_exec", arm_exec)
    bump_stat(db, "arm_success", arm_ok)
    bump_stat(db, "arm_fail", arm_bad)
    db.commit()

    new_coins = db.execute("SELECT coins FROM users WHERE id = ?", (uid,)).fetchone()["coins"]
    order_id = db.execute("SELECT last_insert_rowid() AS i").fetchone()["i"]
    return jsonify(
        ok=True, order_id=order_id, status=status, paid=delivered_total,
        coins=new_coins, items=line_items,
        arm={"exec": arm_exec, "success": arm_ok, "fail": arm_bad},
    )


@app.route("/api/stats")
def api_stats():
    db = get_db()
    orders = db.execute("SELECT COUNT(*) c, COALESCE(SUM(total),0) t FROM orders").fetchone()
    recent = db.execute(
        "SELECT id, user_id, ip, total, status, arm_exec, arm_success, arm_fail, items, created_at "
        "FROM orders ORDER BY id DESC LIMIT 15"
    ).fetchall()
    users_c = db.execute("SELECT COUNT(*) c FROM users").fetchone()["c"]
    return jsonify(
        ok=True,
        page_visits=int(stat_val(db, "page_visits")),
        order_count=orders["c"],
        total_sales=round(orders["t"], 2),
        arm_exec=int(stat_val(db, "arm_exec")),
        arm_success=int(stat_val(db, "arm_success")),
        arm_fail=int(stat_val(db, "arm_fail")),
        user_count=users_c,
        recent_orders=[dict(r) for r in recent],
    )


# ------------------ 后台：新增商品 / 补货 / 上报机械臂 ------------------
@app.route("/api/products", methods=["POST"])
def api_add_product():
    data = request.get_json(force=True, silent=True) or {}
    name = (data.get("name") or "").strip()
    if not name:
        return jsonify(ok=False, msg="商品名必填"), 400
    try:
        price = float(data.get("price"))
        stock = int(data.get("stock"))
    except (TypeError, ValueError):
        return jsonify(ok=False, msg="价格/库存格式错误"), 400
    category = (data.get("category") or "零食").strip()
    emoji = (data.get("emoji") or "📦").strip()

    db = get_db()
    db.execute(
        "INSERT INTO products(name,category,price,stock,emoji,created_at) VALUES(?,?,?,?,?,?)",
        (name, category, price, stock, emoji, now_str()),
    )
    db.commit()
    pid = db.execute("SELECT last_insert_rowid() AS i").fetchone()["i"]
    return jsonify(ok=True, id=pid)


@app.route("/api/products/<int:pid>/restock", methods=["POST"])
def api_restock(pid):
    data = request.get_json(force=True, silent=True) or {}
    try:
        add = int(data.get("add"))
    except (TypeError, ValueError):
        return jsonify(ok=False, msg="补货数量错误"), 400
    db = get_db()
    p = db.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
    if not p:
        return jsonify(ok=False, msg="商品不存在"), 404
    db.execute("UPDATE products SET stock = stock + ? WHERE id=?", (add, pid))
    db.commit()
    return jsonify(ok=True, stock=p["stock"] + add)


@app.route("/api/backup", methods=["POST"])
def api_backup():
    """后台手动触发一次数据库备份。"""
    dst = snapshot_db()
    if not dst:
        return jsonify(ok=False, msg="数据库尚不存在"), 404
    files = sorted(glob.glob(os.path.join(BACKUP_DIR, "vending_*.db")), reverse=True)
    return jsonify(ok=True, file=os.path.basename(dst), total=len(files))


@app.route("/api/backups")
def api_backups():
    """列出已有备份。"""
    files = sorted(glob.glob(os.path.join(BACKUP_DIR, "vending_*.db")), reverse=True)
    out = [{"name": os.path.basename(f), "size": os.path.getsize(f),
            "mtime": datetime.fromtimestamp(os.path.getmtime(f)).strftime("%Y-%m-%d %H:%M:%S")}
           for f in files]
    return jsonify(ok=True, backups=out)


@app.route("/api/download-db")
def api_download_db():
    """下载当前数据库文件（可离线保存/迁移）。"""
    if not os.path.exists(DB_PATH):
        return jsonify(ok=False, msg="数据库尚不存在"), 404
    return send_file(DB_PATH, as_attachment=True, download_name="vending.db")


@app.route("/api/arm/report", methods=["POST"])
def api_arm_report():
    """真实机器人上报一次机械臂动作结果（可选，供硬件联调）。"""
    data = request.get_json(force=True, silent=True) or {}
    success = bool(data.get("success"))
    db = get_db()
    bump_stat(db, "arm_exec", 1)
    bump_stat(db, "arm_success", 1 if success else 0)
    bump_stat(db, "arm_fail", 0 if success else 1)
    db.commit()
    return jsonify(ok=True)


# ============================================================================
# 通用数据库读写接口 —— 开放给 agent 框架直接改库（表名/列名白名单，防注入）
# ============================================================================
DB_TABLES = {
    "products": {"pk": "id",  "auto": True,
                 "cols": {"name", "category", "price", "stock", "emoji", "created_at"}},
    "users":    {"pk": "id",  "auto": False,
                 "cols": {"id", "ip", "coins", "visits", "created_at", "last_seen"}},
    "orders":   {"pk": "id",  "auto": True,
                 "cols": {"user_id", "ip", "items", "total", "arm_exec", "arm_success",
                          "arm_fail", "status", "created_at"}},
    "stats":    {"pk": "key", "auto": False, "cols": {"key", "value"}},
}


@app.route("/api/db/<table>", methods=["GET"])
def api_db_list(table):
    """读取某张表的全部行。"""
    spec = DB_TABLES.get(table)
    if not spec:
        return jsonify(ok=False, msg="未知数据表"), 404
    db = get_db()
    rows = db.execute(f"SELECT * FROM {table}").fetchall()
    return jsonify(ok=True, table=table, rows=[dict(r) for r in rows])


@app.route("/api/db/<table>", methods=["POST"])
def api_db_upsert(table):
    """新增或更新一行：带主键且已存在 → 更新提供的列；否则插入。"""
    if not check_token():
        return jsonify(ok=False, msg="未授权（需 X-API-Token）"), 401
    spec = DB_TABLES.get(table)
    if not spec:
        return jsonify(ok=False, msg="未知数据表"), 404
    data = request.get_json(force=True, silent=True) or {}
    fields = {k: v for k, v in data.items() if k in spec["cols"]}
    if not fields:
        return jsonify(ok=False, msg="没有合法列"), 400

    pk = spec["pk"]
    db = get_db()
    pk_val = data.get(pk)
    exists = pk_val is not None and db.execute(
        f"SELECT 1 FROM {table} WHERE {pk}=?", (pk_val,)).fetchone() is not None

    if exists:
        setcols = {k: v for k, v in fields.items() if k != pk}
        if setcols:
            assigns = ", ".join(f"{k}=?" for k in setcols)
            db.execute(f"UPDATE {table} SET {assigns} WHERE {pk}=?",
                       (*setcols.values(), pk_val))
        row_key = pk_val
    else:
        if "created_at" in spec["cols"] and "created_at" not in fields:
            fields["created_at"] = now_str()
        cols = list(fields.keys())
        ph = ",".join("?" for _ in cols)
        db.execute(f"INSERT INTO {table}({','.join(cols)}) VALUES({ph})",
                   tuple(fields[c] for c in cols))
        row_key = (pk_val if pk_val is not None
                   else db.execute("SELECT last_insert_rowid() AS i").fetchone()["i"])
    db.commit()
    row = db.execute(f"SELECT * FROM {table} WHERE {pk}=?", (row_key,)).fetchone()
    return jsonify(ok=True, table=table, row=dict(row) if row else None)


@app.route("/api/db/<table>/<key>", methods=["DELETE"])
def api_db_delete(table, key):
    """按主键删除一行。"""
    if not check_token():
        return jsonify(ok=False, msg="未授权（需 X-API-Token）"), 401
    spec = DB_TABLES.get(table)
    if not spec:
        return jsonify(ok=False, msg="未知数据表"), 404
    db = get_db()
    cur = db.execute(f"DELETE FROM {table} WHERE {spec['pk']}=?", (key,))
    db.commit()
    return jsonify(ok=True, deleted=cur.rowcount)


# ============================================================================
# LoopViz —— LoopMaster 四角色（Handler/Strategist/Worker/Auditor）可视化
# 只读扫描 ../loopmaster 的 run 产物与技能注册表，整合进本站，不改动 loopmaster。
# ============================================================================
LV_ROLES = {
    "handler": {
        "name": "Handler", "cn": "调度官", "icon": "🎛️", "color": "#f5a524",
        "duty": "Owns the run, workspace, robot connection, and role handoff.",
        "duty_cn": "掌管整轮运行、工作区、机器人连接，并按顺序移交给其余三个子代理。",
        "contract": ("You own the LoopMaster run and hand off to Strategist, Worker, and Auditor. "
                     "Do not execute shell commands or edit files."),
        "produces": ["handler_agent.json", "(workspace)"],
        "skill_relation": "拥有整个技能注册表，但自己不执行技能——只连接平台、分发任务。",
    },
    "strategist": {
        "name": "Strategist", "cn": "策略师", "icon": "🧭", "color": "#a855f7",
        "duty": "Selects registry-backed skills from the goal and writes plan.md.",
        "duty_cn": "从目标出发，在技能注册表里挑选可用技能，产出 plan.md。",
        "contract": ("Produce a registry-grounded plan for a real robot. Use only provided skill names. "
                     "Keep stop_motion at the end when any control skill appears."),
        "produces": ["plan.md", "strategist_agent.json"],
        "skill_relation": "从全部已注册技能中筛选并编排出计划步骤（selected）。",
    },
    "worker": {
        "name": "Worker", "cn": "执行官", "icon": "🦾", "color": "#22d3ee",
        "duty": "Executes the plan, observes after control actions, writes summary.md / trace.jsonl.",
        "duty_cn": "执行计划里的每个技能，控制动作后自动 observe，失败则 stop_motion，写轨迹与总结。",
        "contract": ("Review the plan before local code executes registered platform skills. "
                     "Return proceed=false only for a concrete safety or registry issue."),
        "produces": ["trace.jsonl", "summary.md", "worker_agent.json"],
        "skill_relation": "真正调用（execute）技能，并自动注入 observe / stop_motion 安全动作。",
    },
    "auditor": {
        "name": "Auditor", "cn": "审计官", "icon": "🔍", "color": "#34d399",
        "duty": "Reviews trace evidence, detects missing learned skills, writes review.md.",
        "duty_cn": "依据轨迹证据判定结果（done/retry/blocked/research_needed），发现缺失的可学习技能。",
        "contract": ("Independently review the plan and trace. Classify the run as done, retry, "
                     "blocked, or research_needed. Do not execute tools or edit files."),
        "produces": ["review.md", "auditor_agent.json"],
        "skill_relation": "不执行技能，只评估用了哪些技能、控制技能是否安全收尾、是否有仿真泄漏。",
    },
}
LV_CONTROL_SKILLS = {"send_action", "move_arm_joints", "set_gripper", "set_base_velocity", "set_lift_height"}


def _lv_parse_frontmatter(text):
    if not text.startswith("---"):
        return {}, text
    m = re.search(r"\n---\s*\n", text[3:])
    if not m:
        return {}, text
    raw = text[3:m.start() + 3]
    body = text[m.end() + 3:]
    data, cur = {}, None
    for line in raw.splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if not line.startswith(" ") and ":" in line:
            k, v = line.split(":", 1)
            k, v = k.strip(), v.strip()
            if v:
                data[k] = v
                cur = None
            else:
                data[k] = {}
                cur = data[k]
        elif cur is not None and ":" in line:
            k, v = line.split(":", 1)
            cur[k.strip()] = v.strip()
    return data, body


def lv_load_skills():
    roots = [(LOOP_SKILL_ROOT, False)]
    user_root = Path(os.environ.get("LOOPMASTER_SKILL_ROOT", "~/.loopmaster/skills")).expanduser()
    roots.append((user_root, True))
    out = {}
    for root, is_user in roots:
        if not root.exists():
            continue
        for md in root.rglob("SKILL.md"):
            fm, body = _lv_parse_frontmatter(md.read_text(encoding="utf-8"))
            rel = md.parent.relative_to(root).parts
            name = fm.get("name") or md.parent.name
            if name in out:
                continue
            category = fm.get("category") or "/".join(rel[:-1]) or "base"
            out[name] = {
                "name": name,
                "category": category,
                "group": category.split("/")[-1],
                "description": fm.get("description") or "",
                "args": fm.get("args") if isinstance(fm.get("args"), dict) else {},
                "is_user": is_user,
                "is_control": name in LV_CONTROL_SKILLS,
                "body": body.strip(),
            }
    return sorted(out.values(), key=lambda s: (s["group"], s["name"]))


def _lv_run_roots():
    seen, roots = set(), []
    for p in [os.environ.get("LOOPMASTER_WORKSPACE_ROOT"),
              str(LOOP_REPO / "_viz_runs"),
              str(Path("~/.loopmaster/workspaces").expanduser())]:
        if not p:
            continue
        rp = Path(p).expanduser()
        if rp.exists() and str(rp) not in seen:
            seen.add(str(rp))
            roots.append(rp)
    return roots


def _lv_list_runs():
    runs = []
    for root in _lv_run_roots():
        for d in root.iterdir():
            if d.is_dir() and (d / "plan.md").exists():
                runs.append(d)
    runs.sort(key=lambda d: d.stat().st_mtime, reverse=True)
    return runs


def _lv_read(path):
    return path.read_text(encoding="utf-8") if path.exists() else ""


def _lv_load_json(path):
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def _lv_parse_plan_md(text):
    sections, cur = {}, None
    for line in text.splitlines():
        h = re.match(r"^##\s+(.*)", line)
        if h:
            cur = h.group(1).strip()
            sections[cur] = []
        elif cur:
            sections[cur].append(line)
    title = ""
    tm = re.match(r"^#\s+Plan:\s*(.*)", text)
    if tm:
        title = tm.group(1).strip()

    def bullets(key):
        out = []
        for ln in sections.get(key, []):
            m = re.match(r"^-\s+(.*)", ln.strip())
            if m:
                out.append(m.group(1).strip())
        return out

    steps = []
    for ln in sections.get("Steps", []):
        m = re.match(r"^\s*(\d+)\.\s+`([^`]+)`\s+args=(\{.*?\})(?:\s+-\s+(.*))?$", ln)
        if m:
            try:
                args = ast.literal_eval(m.group(3))
            except (ValueError, SyntaxError):
                args = {}
            steps.append({"idx": int(m.group(1)), "skill": m.group(2),
                          "args": args, "why": (m.group(4) or "").strip()})
    goal = " ".join(l.strip() for l in sections.get("Goal", []) if l.strip())
    return {
        "title": title, "goal": goal, "steps": steps,
        "success_criteria": bullets("Success Criteria"),
        "risks": bullets("Risks"),
        "assumptions": bullets("Assumptions"),
        "research_questions": bullets("Research Questions"),
        "subagent_notes": bullets("Subagent Notes"),
    }


def _lv_parse_review_md(text):
    def grab(label):
        m = re.search(rf"\*\*{label}\*\*:\s*`?([^`\n]*)`?", text)
        return (m.group(1).strip() if m else "").strip("`")

    def listline(label):
        m = re.search(rf"^-\s+{label}:\s*(.*)$", text, re.MULTILINE)
        if not m:
            return []
        val = m.group(1).strip()
        if val in ("(none)", ""):
            return []
        return [x.strip() for x in val.split(",") if x.strip()]

    research = []
    if "## Research Needed" in text:
        tail = text.split("## Research Needed", 1)[1]
        research = [m.group(1).strip() for m in re.finditer(r"^-\s+(.*)$", tail, re.MULTILINE)]
    return {
        "verdict": grab("Verdict") or "unknown",
        "root_cause": grab("Root cause"),
        "next_action": grab("Next action"),
        "used_skills": listline("Used skills"),
        "used_control_skills": listline("Used control skills"),
        "sim_leak": listline("Simulation leak terms"),
        "research_questions": research,
    }


def _lv_parse_trace(path):
    steps = []
    if not path.exists():
        return steps
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            steps.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return steps


def _lv_parse_run(run_dir):
    plan = _lv_parse_plan_md(_lv_read(run_dir / "plan.md"))
    review = _lv_parse_review_md(_lv_read(run_dir / "review.md"))
    trace = _lv_parse_trace(run_dir / "trace.jsonl")
    dirname = run_dir.name
    m = re.search(r"-(\d{8}-\d{6}-[0-9a-f]{6})$", dirname)
    run_id = m.group(1) if m else dirname
    task = plan.get("title") or dirname
    ok_n = sum(1 for s in trace if s.get("ok"))
    roles_seen = sorted({s.get("role", "worker") for s in trace})
    return {
        "run_id": run_id,
        "task": task,
        "dir": str(run_dir),
        "mtime": run_dir.stat().st_mtime,
        "verdict": review["verdict"],
        "success": review["verdict"] == "done",
        "plan": plan,
        "review": review,
        "trace": trace,
        "summary_md": _lv_read(run_dir / "summary.md"),
        "trace_stats": {"total": len(trace), "ok": ok_n, "fail": len(trace) - ok_n, "roles": roles_seen},
        "agent_json": {
            "handler": _lv_load_json(run_dir / "handler_agent.json"),
            "strategist": _lv_load_json(run_dir / "strategist_agent.json"),
            "worker": _lv_load_json(run_dir / "worker_agent.json"),
            "auditor": _lv_load_json(run_dir / "auditor_agent.json"),
        },
        "artifacts": sorted(p.name for p in run_dir.iterdir() if p.is_file()),
    }


@app.route("/loopviz")
def loopviz():
    return render_template("loopviz.html")


@app.route("/api/loopviz/skills")
def api_lv_skills():
    return jsonify(ok=True, skills=lv_load_skills(), roles=LV_ROLES)


@app.route("/api/loopviz/runs")
def api_lv_runs():
    runs = _lv_list_runs()
    brief = []
    for d in runs:
        r = _lv_parse_review_md(_lv_read(d / "review.md"))
        pm = re.match(r"^#\s+Plan:\s*(.*)", _lv_read(d / "plan.md"))
        brief.append({
            "id": d.name,
            "task": (pm.group(1).strip() if pm else d.name),
            "verdict": r["verdict"],
            "mtime": d.stat().st_mtime,
        })
    return jsonify(ok=True, runs=brief, roots=[str(x) for x in _lv_run_roots()])


@app.route("/api/loopviz/run/<path:run_id>")
def api_lv_run(run_id):
    for root in _lv_run_roots():
        cand = root / run_id
        if cand.exists() and (cand / "plan.md").exists():
            return jsonify(ok=True, run=_lv_parse_run(cand), roles=LV_ROLES,
                           control_skills=sorted(LV_CONTROL_SKILLS))
    return jsonify(ok=False, msg="run not found"), 404


# ------------------ LoopViz 写接口：供 agent 框架推送运行/技能 ------------------
LV_RUN_FILES = {"plan.md", "trace.jsonl", "review.md", "summary.md",
                "handler_agent.json", "strategist_agent.json",
                "worker_agent.json", "auditor_agent.json"}


def _lv_write_root():
    env = os.environ.get("LOOPMASTER_WORKSPACE_ROOT")
    root = Path(env).expanduser() if env else (LOOP_REPO / "_viz_runs")
    root.mkdir(parents=True, exist_ok=True)
    return root


@app.route("/api/loopviz/run", methods=["POST"])
def api_lv_write_run():
    """agent 框架推送一次运行：{id, files:{"plan.md":..,"trace.jsonl":..,"*_agent.json":{..}}}。
    dict/list 内容自动转 JSON；文件名白名单过滤。"""
    if not check_token():
        return jsonify(ok=False, msg="未授权（需 X-API-Token）"), 401
    data = request.get_json(force=True, silent=True) or {}
    run_id = (data.get("id") or "").strip()
    files = data.get("files") or {}
    if not run_id or "/" in run_id or "\\" in run_id or run_id.startswith("."):
        return jsonify(ok=False, msg="非法 run id"), 400

    run_dir = _lv_write_root() / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    written = []
    for fname, content in files.items():
        if fname not in LV_RUN_FILES:
            continue
        if isinstance(content, (dict, list)):
            content = json.dumps(content, ensure_ascii=False, indent=2)
        (run_dir / fname).write_text(str(content), encoding="utf-8")
        written.append(fname)
    # 保底 plan.md，确保运行能被列表识别
    if not (run_dir / "plan.md").exists():
        (run_dir / "plan.md").write_text(f"# Plan: {run_id}\n", encoding="utf-8")
    return jsonify(ok=True, id=run_id, dir=str(run_dir), written=written,
                   run=_lv_parse_run(run_dir))


@app.route("/api/loopviz/run/<path:run_id>", methods=["DELETE"])
def api_lv_delete_run(run_id):
    """删除一次运行目录。"""
    if not check_token():
        return jsonify(ok=False, msg="未授权（需 X-API-Token）"), 401
    import shutil
    for root in _lv_run_roots():
        cand = root / run_id
        if cand.exists() and cand.is_dir():
            shutil.rmtree(cand)
            return jsonify(ok=True, deleted=run_id)
    return jsonify(ok=False, msg="run not found"), 404


@app.route("/api/loopviz/skill", methods=["POST"])
def api_lv_write_skill():
    """agent 框架注册/更新一个技能，写入用户技能目录（LOOPMASTER_SKILL_ROOT，默认 ~/.loopmaster/skills）。
    body: {name, category, description, args:{..}, body, }"""
    if not check_token():
        return jsonify(ok=False, msg="未授权（需 X-API-Token）"), 401
    data = request.get_json(force=True, silent=True) or {}
    name = (data.get("name") or "").strip()
    if not name or not re.match(r"^[A-Za-z0-9_.-]+$", name):
        return jsonify(ok=False, msg="非法技能名"), 400
    category = (data.get("category") or "base").strip().strip("/") or "base"
    description = (data.get("description") or "").replace("\n", " ").strip()
    args = data.get("args") if isinstance(data.get("args"), dict) else {}
    body = str(data.get("body") or "").strip()

    root = Path(os.environ.get("LOOPMASTER_SKILL_ROOT", "~/.loopmaster/skills")).expanduser()
    skill_dir = root / category / name
    skill_dir.mkdir(parents=True, exist_ok=True)
    lines = ["---", f"name: {name}", f"category: {category}"]
    if description:
        lines.append(f"description: {description}")
    if args:
        lines.append("args:")
        lines += [f"  {k}: {v}" for k, v in args.items()]
    lines += ["---", "", body, ""]
    (skill_dir / "SKILL.md").write_text("\n".join(lines), encoding="utf-8")
    return jsonify(ok=True, name=name, category=category, path=str(skill_dir / "SKILL.md"))


if __name__ == "__main__":
    init_db()
    snap = snapshot_db()          # 启动即自动快照，防止误删
    if snap:
        print("  启动快照:", os.path.basename(snap))
    print("=" * 48)
    print("  叫卖侠 · 双臂销售机器人售卖系统")
    print("  下单页 : http://127.0.0.1:5000/")
    print("  数据大屏: http://127.0.0.1:5000/dashboard")
    print("  后台管理: http://127.0.0.1:5000/admin")
    print("  智能体页: http://127.0.0.1:5000/loopviz")
    print("=" * 48)
    app.run(host="0.0.0.0", port=5000, debug=True)
